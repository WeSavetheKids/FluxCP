<?php
return array(
	'modules' => array(
		'skyzone' => array(
			'index' => AccountLevel::UNAUTH
		)
	),
	'features' => array(
		// None.
	)
)
?>
